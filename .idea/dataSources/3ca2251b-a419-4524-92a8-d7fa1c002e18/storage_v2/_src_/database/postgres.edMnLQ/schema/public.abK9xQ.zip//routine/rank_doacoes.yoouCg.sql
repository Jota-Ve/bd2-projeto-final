create function rank_doacoes(k integer)
    returns TABLE(nro_plataforma integer, nome_canal text, quantidade_doacoes bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        d.nro_plataforma,
        d.nome_canal,
        COUNT(*) AS quantidade_doacoes
    FROM
        doacao d
    GROUP BY
        d.nro_plataforma,
        d.nome_canal
    ORDER BY
        quantidade_doacoes DESC
    LIMIT
        k;
END;
$$;

alter function rank_doacoes(integer) owner to postgres;

