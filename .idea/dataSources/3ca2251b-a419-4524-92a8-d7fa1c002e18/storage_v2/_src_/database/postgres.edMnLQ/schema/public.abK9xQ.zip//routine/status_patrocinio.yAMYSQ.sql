create function status_patrocinio(company_nbr integer DEFAULT NULL::integer)
    returns TABLE(nro_empresa integer, nome_fantasia text, nro_plataforma integer, nome_canal text, valor_usd numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        e.nro,
        e.nome_fantasia,
        p.nro_plataforma,
        p.nome_canal,
        p.valor AS valor_USD
    FROM
        patrocinio p
    JOIN
        empresa e ON e.nro = p.nro_empresa
    WHERE
        company_nbr IS NULL OR e.nro = company_nbr
    ORDER BY
        e.nro,
        p.valor DESC;
END;
$$;

alter function status_patrocinio(integer) owner to postgres;

