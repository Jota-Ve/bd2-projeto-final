create function rank_patrocinios(k integer)
    returns TABLE(nro_plataforma integer, nome_canal text, quantidade_patrocinios bigint, valor_total_patrocinios_usd numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        p.nro_plataforma,
        p.nome_canal,
        COUNT(*) AS quantidade_patrocinios,
        SUM(p.valor) AS valor_total_patrocinios_USD
    FROM
        patrocinio p
    GROUP BY
        p.nro_plataforma,
        p.nome_canal
    ORDER BY
        valor_total_patrocinios_USD DESC
    LIMIT
        k;
END;
$$;

alter function rank_patrocinios(integer) owner to postgres;

