create function status_doacao(channel_name text DEFAULT NULL::text)
    returns TABLE(nro_plataforma integer, nome_canal text, total_doacoes_usd numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        d.nro_plataforma,
        d.nome_canal,
        ROUND(SUM(d.valor * cvs.fator_conver), 2) AS total_doacoes_USD
    FROM
        doacao d
    JOIN comentario c ON d.nro_plataforma = c.nro_plataforma
                      AND d.nome_canal = c.nome_canal
                      AND d.titulo_video = c.titulo_video
                      AND d.datah_video = c.datah_video
                      AND d.nick_usuario = c.nick_usuario
                      AND d.seq_comentario = c.seq
    JOIN usuario u ON c.nick_usuario = u.nick
    JOIN pais p ON u.pais_resid = p.nome
    join conversao cvs ON p.moeda = cvs.moeda
    WHERE
        (channel_name IS NULL OR d.nome_canal = channel_name)
        AND d.status <> 'recusado'
    GROUP BY
        d.nro_plataforma,
        d.nome_canal
    ORDER BY
        total_doacoes_USD DESC;
END;
$$;

alter function status_doacao(text) owner to postgres;

